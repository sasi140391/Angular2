import { OnlineStoreAppPage } from './app.po';

describe('online-store-app App', () => {
  let page: OnlineStoreAppPage;

  beforeEach(() => {
    page = new OnlineStoreAppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
