import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class CRUDService {
  private apiProductURL = 'https://stockdb-2956.restdb.io/rest/products';
  private apiStudentURL = 'https://stockdb-2956.restdb.io/rest/student-records';
  private headerOptions = new RequestOptions();

  constructor(private _http: Http) {
    this.headerOptions.headers = new Headers({
      'content-type': 'application/json',
      'x-apikey': '599d67cebf78f0d50ea2f182',
      'cache-control': 'no-cache'
    });
  }

  deleteParams(): void {
    if (this.headerOptions.params) {
      this.headerOptions.params.delete('q');
    }
  }

  getAllProducts(): Observable<any> {
    this.deleteParams();
    return this._http
      .get(this.apiProductURL, this.headerOptions)
      .map((res: Response) => res.json());
  }

  getProduct(id: any): Observable<any> {
    if (!id) {
      return null;
    }
    this.deleteParams();
    this.headerOptions.params = new URLSearchParams('q=' + JSON.stringify({'_id' : id}));

    return this._http
      .get(this.apiProductURL, this.headerOptions)
      .map((res: Response) => res.json());

  }

  addProduct(data: Object): Observable<any> {
    this.deleteParams();
    return this._http
        .post(this.apiProductURL, JSON.stringify(data), this.headerOptions)
        .map((res: Response) => res.json());
  }

  updateProduct(id: any, data: Object): Observable<any> {
    this.deleteParams();
    return this._http
        .put(this.apiProductURL + '/' + id, JSON.stringify(data), this.headerOptions)
        .map((res: Response) => res.json());
  }

  deleteProduct(id: any): Observable<any> {
    if (!id) {
      return null;
    }
    this.deleteParams();
    return this._http
        .delete(this.apiProductURL + '/' + id, this.headerOptions)
        .map((res: Response) => res.json());
  }

  getStudentRecords(): Observable<any> {
    this.deleteParams();
    return this._http
      .get(this.apiStudentURL, this.headerOptions)
      .map((res: Response) => res.json());
  }

}
