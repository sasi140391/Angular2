import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class DbService {

  // This service requests the JSON-SERVER(fake REST API Client)
  // You can install JSON-SERVER using npm i -g json-server@latest
  private requestURL = 'http://localhost:3000/students';

  // The following URL uses the local JSON file as its record
  // Uncomment the below line if you don't have the JSON-SERVER in your system
  // private requestURL = 'db/Student_records.json';

  constructor(private _http: Http) { }

  getStudentRecords(requestParams: Object = null): Observable<any> {
    let myParams = new URLSearchParams();

    if (requestParams && (requestParams['pageNumber'] > 0)) {
      myParams.append('_sort', 'student_dob');
      myParams.append('_order', requestParams['sortOrder']);
      myParams.append('_limit', requestParams['perPageCount']);
      myParams.append('_page', requestParams['pageNumber']);
    }

    const options = new RequestOptions({params: myParams});

    return this._http
      .get(this.requestURL, options)
      .map(res => res.json());
  }

}
