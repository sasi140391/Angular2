import { Component, OnInit, ViewEncapsulation } from '@angular/core';

import { DbService } from './db.service';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [DbService]
})
export class PaginationComponent implements OnInit {

  private studentData: any;
  private hasNoRecords: boolean;
  private pageNumber: number;
  private totalPages: number;
  private perPageCount: number;
  private sortOrder: string;

  constructor(private _db: DbService) {
    this.pageNumber = 1;
    this.perPageCount = 10;
    this.sortOrder = 'ASC';
    if (!this.totalPages) {
      this.getRecords(0);
    }
    this.getRecords();
  }

  ngOnInit() {

  }

  getRecords(page: number = 1) {
    let params: Object = {};
    params['pageNumber'] = page;

    if (this.pageNumber !== page) {
      this.pageNumber = page;
    }

    if (page > 0) {
      params['perPageCount'] = this.perPageCount;
      params['sortOrder'] = this.sortOrder;
    }

    this._db.getStudentRecords(params).subscribe(
      data => {
        if (data.length) {
          if (params['pageNumber'] === 0) {
            this.totalPages = ((data.length) / this.perPageCount);
          } else {
            this.studentData = data;
            this.hasNoRecords = false;
          }
        } else {
          this.hasNoRecords = true;
        }
      }
    );
  }

  getNumberOfStars(n: number): Array<number> {
    let numberOfStars: Array<number> = [];

    for (let i = 1; i <= (n / 2); i++) {
      numberOfStars.push(i);
    }

    // Half-star for odd rating
    if ((n % 2) !== 0) {
      numberOfStars.push(-1);
    }

    return numberOfStars;
  }

  paginate(action: string = '') {
    switch  (action) {
      case 'prev':
        this.pageNumber -= 1;
        break;
      case 'next':
        this.pageNumber += 1;
        break;
    }

    this.getRecords(this.pageNumber);
  }

  getPageNumbers() {
    let pages: Array<number> = [];
    for (let index = 0; index < this.totalPages; index++) {
      pages.push(index + 1);
    }
    return pages;
  }

}
