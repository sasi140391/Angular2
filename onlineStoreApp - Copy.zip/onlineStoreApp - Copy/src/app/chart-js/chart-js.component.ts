import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-chart-js',
  templateUrl: './chart-js.component.html',
  styleUrls: ['./chart-js.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ChartJSComponent implements OnInit {

  private chartType: string;
  private chartData: Object;
  private chartOptions: object;
  private typeOfCharts: Array<string> = ['line', 'bar', 'radar', 'pie', 'doughnut', 'polarArea', 'bubble', 'scatter'];

  constructor() {
    this.drawChart('line');
  }

  ngOnInit() {
  }

  drawChart(type: string): void {
    let dataSetCount = 4;
    this.chartType = type;

    switch (type) {
      case 'radar':
      case 'mixed':
        dataSetCount = 5;
        break;

      case 'doughnut':
      case 'polarArea':
      case 'pie':
        dataSetCount = 1;
        break;

      case 'scatter':
        dataSetCount  = 3;
        break;

      default:
        break;
    }

    this.generateChartData(dataSetCount);
    this.generateChartOptions();
  }

  getRandomValue(min: number = 0, max: number = 100): number {
    return Math.floor(Math.random() * (max - min) ) + min;
  }

  generateRandomData(count: number = 0, min: number = 10, max: number = 100): Array<number> {
    let randomData: Array<number> = [];
    for (let index = 0; index < count; index++) {
      randomData.push(this.getRandomValue(min, max));
    }
    return randomData;
  }

  generateChartData(count: number = 4): any {
    if (count > 8) {
      count = 4;
    }

    this.chartData = {};

    let datasets: Array<object> = [];
    let chartLabels: Array<string> = [];

    const backgroundColor: Array<string> = [
      'rgba(244,67,54,0.5)', // Red
      'rgba(255,214,0,0.5)', // Yellow
      'rgba(3,169,244,0.5)', // Light blue
      'rgba(63,81,181,0.5)', // Indigo
      'rgba(76,175,80,0.5)', // Green
      'rgba(103,58,183,0.5)', // Deep purple
      'rgba(158,158,158,0.5)', // Grey
      'rgba(255,87,34,0.5)', // Deep orange
    ];

    const borderColor: Array<string> = [
      'rgba(244,67,54,1)', // Red
      'rgba(255,214,0,1)', // Yellow
      'rgba(3,169,244,1)', // Light blue
      'rgba(63,81,181,1)', // Indigo
      'rgba(76,175,80,1)', // Green
      'rgba(103,58,183,1)', // Deep purple
      'rgba(158,158,158,1)', // Grey
      'rgba(255,87,34,1)', // Deep orange
    ];

    for (let index = 0; index < count; index++) {
      let setValue: Object = {};

      setValue['label'] = this.getRandomValue(1990, 2017).toString();
      setValue['backgroundColor'] = backgroundColor[index];
      setValue['borderColor'] = borderColor[index];
      setValue['borderWidth'] = 1;
      setValue['fill'] = false;

      if (this.chartType === 'mixed') {
        setValue['type'] = 'bar';
        if (index <= 1 && index < 2 ) {
          setValue['type'] = 'scatter';
        } else if (index > 2 ) {
          setValue['type'] = 'line';
        }
      }

      if (this.chartType === 'radar' || setValue['type'] === 'radar') {
        setValue['data'] = this.generateRandomData(count);
      } else if (this.chartType === 'polarArea' || setValue['type'] === 'polarArea' ||
                this.chartType === 'doughnut' || setValue['type'] === 'doughnut' ||
                this.chartType === 'pie' || setValue['type'] === 'pie'
              ) {
        setValue['data'] = this.generateRandomData(5);
        setValue['backgroundColor'] = setValue['borderColor'] = [];
        for (let j = 0; j < setValue['data'].length; j++) {
          setValue['backgroundColor'][j] = backgroundColor[j];
        }
      } else if (this.chartType === 'scatter' || setValue['type'] === 'scatter') {
        setValue['data'] = [];
        let scatterData: Array<object> = [];
        for (let j = 0; j < count; j++) {
          for (let k = 0; k < 6; k++) {
            scatterData[k] = {
              x: this.getRandomValue(),
              y: this.getRandomValue()
            };
          }
          setValue['data'] = scatterData;
        }
        setValue['borderWidth'] = 2;
        setValue['fill'] = true;
      } else if (this.chartType === 'bubble' || setValue['type'] === 'bubble') {
        setValue['data'] = [];
        for (let j = 0; j < count; j++) {
          setValue['data'][j] = {
            x: this.getRandomValue(10, 90),
            y: this.getRandomValue(10, 90),
            r: this.getRandomValue(10, 15)
          };
        }
        setValue['borderWidth'] = 2;
        setValue['fill'] = true;
      } else {
        setValue['data'] = this.generateRandomData(this.getRandomValue(6, 13));
      }

      if (this.chartType === 'radar') {
        setValue['borderWidth'] = 2;
        setValue['pointBackgroundColor'] = borderColor[index];
      }

      datasets.push(setValue);

      chartLabels.push(setValue['label']);
    }

    datasets.sort((a, b): number => {
        if (a['label'] < b['label']) {
          return -1;
        } else if (a['label'] > b['label']) {
          return 1;
        }
        return 0;
    });

    chartLabels.sort().forEach((element, i) => {
      chartLabels[i] = 'FY - ' + element;
    });

    if (this.chartType === 'polarArea' ||
        this.chartType === 'doughnut' ||
        this.chartType === 'pie') {
      chartLabels = ['Type A', 'Type B', 'Type C', 'Type D', 'Type E'];
    }

    this.chartData = {
      labels: chartLabels,
      datasets: datasets
    }
  }

  generateChartOptions(): void {
     this.chartOptions = {
      responsive: true,
      maintainAspectRatio: true,
      legend: {
        position: 'bottom',
      },
      title: {
        display: true,
        text: (this.chartType + ' Chart').toUpperCase()
      },
      scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
      },
      animation: {
        animateScale: true,
        animateRotate: true
      }
    };

    switch (this.chartType) {
      case 'radar':
      case 'polarArea':
      case 'doughnut':
      case 'pie':
        this.chartOptions['scales'] = {
          xAxes: [{
            display: false
          }],
          yAxes: [{
            display: false
          }],
        }
        break;
      case 'scatter':
        this.chartOptions['scales'] = {
          xAxes: [{
            ticks: {
                beginAtZero: true
            }
          }],
          yAxes: [{
            ticks: {
                beginAtZero: true
            }
          }]
        }
        break;
    }

    if (this.chartType === 'mixed') {
      this.chartType = 'bar';
    }
  }

}
