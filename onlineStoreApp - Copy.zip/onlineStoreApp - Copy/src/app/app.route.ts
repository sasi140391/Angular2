import { ProductComponent } from './product/product.component';
import { ChartJSComponent } from './chart-js/chart-js.component';
import { PaginationComponent } from './pagination/pagination.component';

export const routes = [
  { path: 'products', component: ProductComponent },
  { path: 'chartjs', component: ChartJSComponent },
  { path: 'pagination', component: PaginationComponent },
  { path: '**', redirectTo: '/', pathMatch: 'full' }
];
