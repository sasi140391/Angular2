import {
  Component,
  OnInit,
  Inject,
  forwardRef,
  ViewEncapsulation,
  Host,
  Optional,
  ElementRef,
  ViewChild,
  Input
} from '@angular/core';
import { animate, style, state, trigger, transition } from '@angular/animations';
import { Router, ActivatedRoute } from '@angular/router';

import { FormComponent  } from './form/form.component';

import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { CRUDService } from '../crud.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [CRUDService, SlimLoadingBarService],
  animations: [
    trigger('fadeInOut', [
      transition('void => *', [
        animate('.5s', style({
          opacity: 1
        }))
      ]),
      transition('* => void', [
        animate('.5s', style({
          opacity: 0,
        }))
      ])
    ])
  ]
})
// Type 3 to call ParentComponent using Inheritance
// export class ProductComponent extends AppComponent implements OnInit {

  export class ProductComponent implements OnInit {

  @ViewChild('formModal') formModal: ElementRef;
  @ViewChild('alertModal') alertModal: ElementRef;
  @ViewChild('confirmModal') confirmModal: ElementRef;
  @ViewChild('closeConfirmModal') closeConfirmModal: ElementRef;

  private allProducts: any;
  private hasProducts: boolean;
  private isPageLoading: boolean;
  private modalTitle: string;
  private alertMessage: string;
  private confirmMessage: string;
  private confirmAction: any;
  private productData: any;
  private formType: string;
  private status: string;
  private productid: any;
  private statusMessage: any;
  private showOverlay: boolean;
  private warningMessage: string;

  // Type 1 of using the parent component
  // constructor (@Inject(forwardRef( () => AppComponent )) private appComponent: AppComponent, private activatedRoute: ActivatedRoute) {
  //   this.appComponent.page = this.activatedRoute.snapshot.url[0].path;
  // }

  // Type 2 of using the parent component
  // constructor (@Host() private appComponent: AppComponent, private activatedRoute: ActivatedRoute) {
  //   this.appComponent.page = this.activatedRoute.snapshot.url[0].path;
  // }

  // Type 3 of using the parent component
  constructor (
    private _crud: CRUDService,
    private activatedRoute: ActivatedRoute,
    private slimService: SlimLoadingBarService
    ) {
    this.hasProducts = false;
    this.storeOperation('check');
  }

  ngOnInit() {
    this.isPageLoading = true;
    this.slimService.progress = 50;
    this.slimService.start();
  }

  getProductsAvailable(event: any = ''): void {
    this.status = '';
    this.statusMessage = '';

    this.showOverlay = true;

    if (event.state === 'saved') {
      this.statusMessage = 'Product successfully updated.';
      this.status = 'OK';
    } else if (event.state === 'failed') {
      this.status = 'FAIL';
    } else if (event.state === 'no-change') {
      this.warningMessage = 'Nothing seems to be changed.';
      this.status = 'WARNING';
      this.showOverlay = false;
    }
    this._crud.getAllProducts().subscribe(
      data => {
        if (data.length) {
          this.hasProducts = true;
          this.allProducts = data;
        } else {
          this.hasProducts = false;
        }
        this.slimService.progress = 100;
        this.slimService.complete();
        this.isPageLoading = false;
        this.showOverlay = false;
      }
    );
  }

  storeOperation(op: string = '', id: string = ''): void {
    this.formType = '';

    if (op !== 'check') {
      this.formType = op;
    }

    if (id) {
      this.productData = '';
      this._crud.getProduct(id).subscribe(
        data => {
          if (data) {
            this.productData = data[0];
          }
        }
      );
    }

    switch (op) {
      case 'check':
          this.getProductsAvailable();
        break;

      case 'add':
          this.modalTitle = 'Add product';
          this.showModal(this.formModal);
        break;

      case 'edit':
          if (id) {
            this.modalTitle = 'Update product';
            this.showModal(this.formModal);
          } else {
            this.alertMessage = 'Problem getting your product.';
            this.showModal(this.alertModal);
          }
        break;

      case 'delete':
          if (id) {
            this.productid = id;
            this.confirmMessage = 'Are you sure want to delete the product?'
            this.confirmAction = 'deleteProduct';            ;
            this.showModal(this.confirmModal);
          } else {
            this.alertMessage = 'Problem getting your product.';
            this.showModal(this.alertModal);
          }
        break;

      case 'view':
          if (id) {
            this.modalTitle = 'Product details';
            this.showModal(this.formModal);
          } else {
            this.alertMessage = 'Problem getting your product.';
            this.showModal(this.alertModal);
          }
        break;

      default:
        break;
    }
  }

  deleteProduct(): void {
    this._crud.deleteProduct(this.productid).subscribe(
      data => {
        if (data) {
          this.getProductsAvailable();
          this.showModal(this.closeConfirmModal);
          this.statusMessage = 'Product successfully deleted.';
          this.status = 'OK';
        } else {
          this.status = 'FAIL';
        }
      }
    );
  }

  showModal(modalType: ElementRef): void {
    modalType.nativeElement.click();
  }
}
