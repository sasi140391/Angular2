import { Component, OnInit, Input, Output, OnChanges, ViewEncapsulation, EventEmitter, ElementRef, ViewChild } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { animate, style, state, trigger, transition } from '@angular/animations';

import { CRUDService } from '../../crud.service';

@Component({
  selector: 'app-product-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
  providers: [CRUDService],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('fadeInOut', [
      transition('void => *', [
        animate('1s', style({
          opacity: 1
        }))
      ]),
      transition('* => void', [
        animate('1s', style({
          opacity: 0,
        }))
      ])
    ])
  ]
})
export class FormComponent implements OnInit, OnChanges {

  @Input() formType: string;
  @Input() productData: Object;
  @Output() success: EventEmitter<any> = new EventEmitter();

  @ViewChild('closeModal') closeModal: ElementRef;

  private showForm: boolean;
  private status: string;
  private statusMessage: string;
  private animationState: string;
  private productForm: FormGroup;

  constructor(private _crud: CRUDService, private fb: FormBuilder) {
    this.productForm = fb.group({
      'productID': [null, Validators.required],
      'productName': [null, Validators.required],
      'productRate': [null, Validators.compose([Validators.required, Validators.pattern('^[0-9]+.?[0-9]{2}?$')])],
      'productQty': [null, Validators.compose([Validators.required, Validators.pattern('^[0-9]{1,3}?$')])],
      'stockComments': ''
    });
  }

  ngOnInit() {

  }

  ngOnChanges() {
    // Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    // Add 'implements OnChanges' to the class.
    this.resetForm();
    this.showForm = true;

    if (this.formType === 'view' || this.formType === 'delete') {
      this.showForm = false;
    }

    if (this.formType === 'edit' && this.productData) {
      this.productForm.patchValue(this.productData);
    }
  }

  submitForm(formValue: object): void {
    if (this.formType === 'add') {
      this._crud.addProduct(formValue).subscribe(
        data => {
          if (data) {
            this.status = 'OK';
            this.statusMessage = 'Product successfully added.';
            this.success.emit();
            this.resetForm();
          } else {
            this.status = 'FAIL';
          }
          this.hideStatusMessage();
        }
      );
    } else if (this.formType === 'edit' && this.productData) {
      // Get the array keys in the formValue object
      const arrayOfKeys: Array<any> = Object.keys(this.productData);
      let isValuesChanged = false;

      // Check the values of the form against the productData(existing data) to confirm
      // whether the data changed or not
      arrayOfKeys.forEach((key, i) => {
        if (this.productData[key]) {
          if (this.productData[key] != formValue[key]) {
            isValuesChanged = true;
          }
        }
      });

      // Call the update function only if the form data is changed/modified
      if (isValuesChanged) {
        this._crud.updateProduct(this.productData['_id'], formValue).subscribe(
          data => {
            if (data) {
              this.success.emit({'state': 'saved'});
            } else {
              this.success.emit({'state': 'failed'});
            }
            this.closeModal.nativeElement.click();
          }
        );
      } else if (!isValuesChanged) {
        this.success.emit({'state': 'no-change'});
        this.closeModal.nativeElement.click();
      }
    }
  }

  resetForm(): void {
    this.hideStatusMessage();
    this.productForm.reset();
  }

  hideStatusMessage(): void {
    setTimeout(() => {
      this.status = '';
    }, 2000);
  }

}
