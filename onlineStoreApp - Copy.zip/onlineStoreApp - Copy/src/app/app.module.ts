import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';

import { SlimLoadingBarModule } from 'ng2-slim-loading-bar';
import { ChartModule } from 'angular2-chartjs';

import { routes } from './app.route';

import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { FormComponent } from './product/form/form.component';
import { ChartJSComponent } from './chart-js/chart-js.component';
import { PaginationComponent } from './pagination/pagination.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    FormComponent,
    ChartJSComponent,
    PaginationComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot(routes),
    SlimLoadingBarModule.forRoot(),
    ChartModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
